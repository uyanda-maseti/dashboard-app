import React from 'react';

export default function ContactList() {
  return <div>ContactList component</div>;
}