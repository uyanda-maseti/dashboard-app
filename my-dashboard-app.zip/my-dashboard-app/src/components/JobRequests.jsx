import React from 'react';

export default function JobRequests() {
  return <div>JobRequests component</div>;
}