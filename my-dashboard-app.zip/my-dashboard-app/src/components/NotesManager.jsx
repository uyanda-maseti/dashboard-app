import React from 'react';

export default function NotesManager() {
  return <div>NotesManager component</div>;
}