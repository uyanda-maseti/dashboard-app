import React from 'react';

export default function Journal() {
  return <div>Journal component</div>;
}